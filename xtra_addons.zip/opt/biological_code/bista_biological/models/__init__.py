# -*- coding: utf-8 -*-
import product
import sale
import crm_lead
import account_invoice
import purchase
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
