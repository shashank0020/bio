from openerp import models, fields, api
from openerp.tools.translate import _
from openerp.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = "sale.order"

    attention = fields.Char(string="Attention")
    department = fields.Char(string="Department")
    subject = fields.Char(string="Subject")
    is_alternative_offer = fields.Boolean(string="Is Alternative Offer")
    is_optional_quotation = fields.Boolean(string="Is Optional Quotation")
    product_category_id = fields.Many2one('product.category', string="Product Category")
    alternate_offer_one = fields.Many2many('sale.order', 'sale_order_rel_one', 'child_id_one', 'parent_id_one', 'Alternate Order One')
    alternate_offer_two = fields.Many2many('sale.order', 'sale_order_rel_two', 'child_id_two', 'parent_id_two', 'Alternate Order Two')
    sale_order_quote = fields.Char(string="Quote Number")
    special_discount = fields.Float(string="Special Discount")

    @api.depends('order_line.price_total', 'special_discount')
    def _amount_all(self):
        ## Inherit function to add logic for special Discount
        ## subtract special Discount value from total_amount
        """
        Compute the total amounts of the SO.
        """
        for order in self:
            amount_untaxed = amount_tax = 0.0
            for line in order.order_line:
                amount_untaxed += line.price_subtotal
                amount_tax += line.price_tax
            order.update({
                'amount_untaxed': order.pricelist_id.currency_id.round(amount_untaxed),
                'amount_tax': order.pricelist_id.currency_id.round(amount_tax),
                'amount_total': (amount_untaxed + amount_tax) - order.special_discount,
            })

    @api.one
    def copy(self, default=None):
        rec = super(SaleOrder, self).copy(default)
        return rec

    @api.multi
    def action_confirm(self):
        default = {}
        for order in self:
            order.state = 'sale'
            order.quotation_id = order.id
            ## To copy referance record for quotation
            default.update({
                        'name': order.name,
                        'partner_id': order.partner_id.id,
                        'partner_invoice_id': order.partner_invoice_id.id,
                        'partner_shipping_id': order.partner_shipping_id.id,
                        'attention': order.attention or False,
                        'department': order.department or False,
                        'pricelist_id': order.pricelist_id.id,
                        'validity_date': order.validity_date,
                        'payment_term_id': order.payment_term_id.id,
                        'subject': order.subject,
                        'is_alternative_offer': order.is_alternative_offer,
                        'is_optional_quotation': order.is_optional_quotation,
                        'product_category_id': order.product_category_id.id,
                        'warehouse_id': order.warehouse_id.id,
                        'picking_policy': order.picking_policy,
                        })
            res1 = self.copy(default)
            order.sale_order_quote = order.name
            sale_quote_seq = self.env['ir.sequence'].get('sale.order.confirmed')
            if sale_quote_seq:
                order.name = sale_quote_seq
            order.confirmation_date = fields.Datetime.now()
            if self.env.context.get('send_email'):
                self.force_quotation_send()
            order.order_line._action_procurement_create()
        if self.env['ir.values'].get_default('sale.config.settings', 'auto_done_setting'):
            self.action_done()
        return True

    @api.multi
    def _prepare_invoice(self):
        """
        Prepare the dict of values to create the new invoice for a sales order. This method may be
        overridden to implement custom invoice generation (making sure to call super() to establish
        a clean extension chain).
        """
        ## Inherit function to pass special discount to invoice while creating from So
        self.ensure_one()
        journal_id = self.env['account.invoice'].default_get(['journal_id'])['journal_id']
        if not journal_id:
            raise UserError(_('Please define an accounting sale journal for this company.'))
        invoice_vals = {
            'name': self.client_order_ref or '',
            'origin': self.name,
            'type': 'out_invoice',
            'account_id': self.partner_invoice_id.property_account_receivable_id.id,
            'partner_id': self.partner_invoice_id.id,
            'journal_id': journal_id,
            'currency_id': self.pricelist_id.currency_id.id,
            'comment': self.note,
            'payment_term_id': self.payment_term_id.id,
            'fiscal_position_id': self.fiscal_position_id.id or self.partner_invoice_id.property_account_position_id.id,
            'company_id': self.company_id.id,
            'user_id': self.user_id and self.user_id.id,
            'team_id': self.team_id.id,
            'inv_special_discount': self.special_discount,
        }
        return invoice_vals



class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"


    cust_sale_product_id = fields.Many2one('bs.optional.sale.product', string="Product Line")
    so_line_seq = fields.Integer(string="Sequence")

    @api.model
    def default_get(self, fields_list):
        """
        Logic for serial number of sale order lines
        Overwrite the default value of the sequence field taking into account
        the current number of lines in the Sale order.
        """
        res = super(SaleOrderLine, self).default_get(fields_list)
        res.update({'so_line_seq': len(self._context.get('order_line', [])) + 1})
        return res

class CustOptionalSaleProduct(models.Model):
    _name = "bs.optional.sale.product"
    _rec_name = "name"
    name = fields.Char(string="Name")
    cust_optional_sale_product_line = fields.One2many('bs.optional.sale.product.line', 'order_line_id', string="Product Line")

class CustOptionalSaleProductLine(models.Model):
    _name = "bs.optional.sale.product.line"
    _rec_name = "name"
    name = fields.Char(string="Name")
    order_line_id = fields.Many2one('bs.optional.sale.product', string="Order Line")
    serial_no = fields.Integer(string="Serial No", required="1")
    product_id = fields.Many2one('product.product', string="Product")
    qty = fields.Float(string="Qty")
    unit_price = fields.Float(string="Unit Price")


# class SaleAdvancePaymentInv(models.TransientModel):
#     _inherit = "sale.advance.payment.inv"
#
#     @api.multi
#     def _create_invoice(self, order, so_line, amount):
#         print 'call my function'
#         fkljklf
#         inv_obj = self.env['account.invoice']
#         ir_property_obj = self.env['ir.property']
#
#         account_id = False
#         if self.product_id.id:
#             account_id = self.product_id.property_account_income_id.id
#         if not account_id:
#             prop = ir_property_obj.get('property_account_income_categ_id', 'product.category')
#             prop_id = prop and prop.id or False
#             account_id = order.fiscal_position_id.map_account(prop_id)
#         if not account_id:
#             raise UserError(
#                 _('There is no income account defined for this product: "%s". You may have to install a chart of account from Accounting app, settings menu.') % \
#                     (self.product_id.name,))
#
#         if self.amount <= 0.00:
#             raise UserError(_('The value of the down payment amount must be positive.'))
#         if self.advance_payment_method == 'percentage':
#             amount = order.amount_untaxed * self.amount / 100
#             name = _("Down payment of %s%%") % (self.amount,)
#         else:
#             amount = self.amount
#             name = _('Down Payment')
#
#         invoice = inv_obj.create({
#             'name': order.client_order_ref or order.name,
#             'origin': order.name,
#             'type': 'out_invoice',
#             'reference': False,
#             'account_id': order.partner_id.property_account_receivable_id.id,
#             'partner_id': order.partner_invoice_id.id,
#             'invoice_line_ids': [(0, 0, {
#                 'name': name,
#                 'origin': order.name,
#                 'account_id': account_id,
#                 'price_unit': amount,
#                 'quantity': 1.0,
#                 'discount': 0.0,
#                 'uom_id': self.product_id.uom_id.id,
#                 'product_id': self.product_id.id,
#                 'sale_line_ids': [(6, 0, [so_line.id])],
#                 'invoice_line_tax_ids': [(6, 0, [x.id for x in self.product_id.taxes_id])],
#                 'account_analytic_id': order.project_id.id or False,
#             })],
#             'currency_id': order.pricelist_id.currency_id.id,
#             'payment_term_id': order.payment_term_id.id,
#             'fiscal_position_id': order.fiscal_position_id.id or order.partner_id.property_account_position_id.id,
#             'team_id': order.team_id.id,
#             'inv_special_discount': order.special_discount,
#         })
#         invoice.compute_taxes()
#         return invoice
