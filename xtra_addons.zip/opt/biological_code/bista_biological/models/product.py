# -*- coding: utf-8 -*-

from openerp.osv import osv, fields, expression
from openerp.tools.translate import _

class product_template(osv.osv):
    _inherit = "product.template"
    _columns = {
        'default_code': fields.related('product_variant_ids', 'default_code', type='char', string='Part Number'),
    }


class product_product(osv.osv):
    _inherit = "product.product"
    _columns = {
        'default_code':fields.char('Part number', select=True, required=True)
    }
