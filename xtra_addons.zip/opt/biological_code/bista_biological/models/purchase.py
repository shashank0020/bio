from openerp import models, fields, api
from openerp.tools.translate import _
from openerp.exceptions import UserError

class PurchaseOrder(models.Model):

    _inherit = "purchase.order"

    end_user = fields.Char(string="End User")
    end_user_statement = fields.Char(string="End User Statement")
