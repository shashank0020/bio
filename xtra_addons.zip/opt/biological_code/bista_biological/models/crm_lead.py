from openerp import models, fields, api
from openerp.tools.translate import _

class CrmLead(models.Model):
    _inherit = "crm.lead"

    bs_currency_id = fields.Many2one('res.currency', string='Currency')
    lead_number = fields.Char(string="Lead Number")
    supplier_id = fields.Many2one('res.partner', string='Suppliers')
    product_ids = fields.Many2many('product.product', string='Products Interested')

    @api.model
    def create(self, vals):
        ## create lead number sequence
        res = super(CrmLead, self).create(vals)
        lead_number_seq = self.env['ir.sequence'].get('crm.lead.number.seq')
        if lead_number_seq:
            res.lead_number = lead_number_seq
        return res
