# -*- coding: utf-8 -*-
##############################################################################
{
      'sequence': 5,

      'name': 'Bista - Biological Addon',
      'version': '1.0',
      'category': '',
      'description': """
Customized for Biological Trading

""",
      'author': '',
      'depends': ['product', 'purchase', 'sale', 'account', 'project'],
      'data': [
            'views/crm_lead_view.xml',
            'views/sale_view.xml',
            'data/ir_sequence.xml',
            'views/account_invoice_view.xml',
            'views/purchase_view.xml',
      ],
      #'data': ['product_view.xml'],
      'demo_xml': [],
      'installable': True,
      'active': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
