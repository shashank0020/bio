

from openerp import api, fields, models, _
import openerp.addons.decimal_precision as dp
from openerp.tools.amount_to_text import amount_to_text
from num2words import num2words

class AccountInvoice(models.Model):
    _inherit = "account.invoice"

    @api.multi
    def conv_amount_to_text(self, amount):
        conv_amt = num2words(amount)
        return conv_amt
