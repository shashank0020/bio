# -*- coding: utf-8 -*-

{
    'name': 'Biological Reports',
    'version': '1.0',
    'category': '',
    'sequence': 9,""
    'summary': '',
    'description': """

    """,
    'author': 'Bista Solutions Pvt. Ltd.',
    'website': 'https://www.odoo.com/es_ES/page/crm',
    'depends': [
        'sale',
    ],
    'data': [
        'sale_report.xml',
        'purchase_report.xml',
        'report/so_header_view.xml',
        'report/so_footer_view.xml',
        'report/sale_order_quotation_report.xml',
        'report/so_terms_condition_view.xml',
        'report/bio_signature.xml',
        'report/po_header.xml',
        'report/purchase_order_report.xml',
        'report/po_term_condition.xml',
        'report/proforma_terms_conditions.xml',
        'report/proforma_report.xml',
        'account_invoice_report.xml',
        'report/invoice_footer.xml',
        'report/commercial_invoice_report.xml',
        'report/packing_list.xml',


     ],
    'demo': [],
    'test': [ ],
    'installable': True,
    'auto_install': True,
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
